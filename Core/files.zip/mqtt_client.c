#include "mqtt_client.h"
#include "mqtt_config.h"
#include "main.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

// =============================================================================
// FORWARD DECLARATION — fungsi W5500 dari main.c
// =============================================================================
extern uint8_t W5500_ReadReg (uint16_t addr, uint8_t block);
extern void    W5500_WriteReg(uint16_t addr, uint8_t block, uint8_t data);
extern void    W5500_WriteBuf(uint16_t addr, uint8_t block, const uint8_t *buf, uint16_t len);
extern void    W5500_ReadBuf (uint16_t addr, uint8_t block, uint8_t *buf, uint16_t len);
extern volatile uint32_t g_ms_tick;

// IP yang didapat DHCP
extern uint8_t g_dhcp_ip[4];

// =============================================================================
// REGISTER W5500 SOCKET 2
// =============================================================================
#define S2_REG_OP    0x48
#define S2_TX_OP     0x50
#define S2_RX_OP     0x58

#define Sn_MR        0x0000
#define Sn_CR        0x0001
#define Sn_IR        0x0002
#define Sn_SR        0x0003
#define Sn_PORT      0x0004
#define Sn_DIPR      0x000C
#define Sn_DPORT     0x0010
#define Sn_TX_FSR    0x0020
#define Sn_TX_WR     0x0024
#define Sn_RX_RSR    0x0026
#define Sn_RX_RD     0x0028

#define SOCK_CLOSED      0x00
#define SOCK_INIT        0x13
#define SOCK_TCP_SYNSENT 0x15
#define SOCK_ESTABLISHED 0x17
#define SOCK_CLOSE_WAIT  0x1C
#define SOCK_FIN_WAIT    0x18

#define CMD_OPEN         0x01
#define CMD_CONNECT      0x04
#define CMD_DISCON       0x08
#define CMD_CLOSE        0x10
#define CMD_SEND         0x20
#define CMD_RECV         0x40

// =============================================================================
// MQTT PACKET TYPE
// =============================================================================
#define MQTT_CONNECT     0x10
#define MQTT_CONNACK     0x20
#define MQTT_PUBLISH     0x30
#define MQTT_PUBACK      0x40
#define MQTT_SUBSCRIBE   0x82
#define MQTT_SUBACK      0x90
#define MQTT_PINGREQ     0xC0
#define MQTT_PINGRESP    0xD0
#define MQTT_DISCONNECT  0xE0

// =============================================================================
// VARIABEL GLOBAL
// =============================================================================
MqttState_t     g_mqtt_state     = MQTT_STATE_IDLE;
uint8_t         g_mqtt_conn_count = 0;
uint32_t        g_mqtt_pub_count  = 0;
MqttSensorData_t g_mqtt_sensor   = {25.0f, 3.30f};

// =============================================================================
// VARIABEL INTERNAL
// =============================================================================
static uint8_t  s_buf[MQTT_BUF_SIZE];
static uint16_t s_pkt_id   = 1;
static uint32_t s_tick_ref = 0;     // referensi waktu untuk timeout/interval
static uint32_t s_last_ping = 0;    // waktu terakhir PINGREQ
static uint32_t s_uptime_sec = 0;   // uptime counter
static uint32_t s_last_uptime = 0;  // untuk hitung uptime
static uint8_t  s_power_state = 0;  // 0=OFF 1=ON
static uint32_t s_pub_interval = 0; // interval publish dari config (ms)
static uint32_t s_last_pub = 0;     // waktu terakhir publish tele

// topic cache
static char s_t_lwt [96];
static char s_t_state[96];
static char s_t_sensor[96];
static char s_t_result[96];
static char s_t_power[96];
static char s_t_cmnd[96];

// =============================================================================
// HELPER: Tunggu CR clear Socket 2
// =============================================================================
static void s2_wait_cr(uint32_t timeout_ms)
{
    uint32_t t = g_ms_tick;
    while (W5500_ReadReg(Sn_CR, S2_REG_OP)) {
        if ((g_ms_tick - t) > timeout_ms) break;
    }
}

// =============================================================================
// HELPER: Kirim data via TCP Socket 2
// =============================================================================
static void s2_send(const uint8_t *data, uint16_t len)
{
    uint16_t ptr = ((uint16_t)W5500_ReadReg(Sn_TX_WR,     S2_REG_OP) << 8) |
                               W5500_ReadReg(Sn_TX_WR + 1, S2_REG_OP);
    W5500_WriteBuf(ptr, S2_TX_OP, data, len);
    ptr += len;
    W5500_WriteReg(Sn_TX_WR,     S2_REG_OP, (uint8_t)(ptr >> 8));
    W5500_WriteReg(Sn_TX_WR + 1, S2_REG_OP, (uint8_t)(ptr));
    W5500_WriteReg(Sn_CR,        S2_REG_OP, CMD_SEND);
    s2_wait_cr(100);
}

// =============================================================================
// HELPER: Encode MQTT remaining length (variable length encoding)
// =============================================================================
static uint8_t encode_remaining(uint8_t *buf, uint32_t len)
{
    uint8_t i = 0;
    do {
        buf[i] = len & 0x7F;
        len >>= 7;
        if (len > 0) buf[i] |= 0x80;
        i++;
    } while (len > 0);
    return i;
}

// =============================================================================
// HELPER: Tulis 2-byte length + string (MQTT string format)
// =============================================================================
static uint16_t write_str(uint8_t *buf, const char *str)
{
    uint16_t len = (uint16_t)strlen(str);
    buf[0] = (uint8_t)(len >> 8);
    buf[1] = (uint8_t)(len);
    memcpy(&buf[2], str, len);
    return 2 + len;
}

// =============================================================================
// HELPER: Format waktu uptime "0T00:05:23"
// =============================================================================
static void format_uptime(char *out, uint32_t sec)
{
    uint32_t days  = sec / 86400;
    uint32_t hours = (sec % 86400) / 3600;
    uint32_t mins  = (sec % 3600)  / 60;
    uint32_t secs  = sec % 60;
    snprintf(out, 16, "%luT%02lu:%02lu:%02lu",
             (unsigned long)days,
             (unsigned long)hours,
             (unsigned long)mins,
             (unsigned long)secs);
}

// =============================================================================
// HELPER: Format timestamp dummy "2026-09-30T13:35:00"
// (tanpa RTC — pakai uptime saja sebagai placeholder)
// =============================================================================
static void format_time(char *out)
{
    // Placeholder — nanti bisa diganti dengan RTC
    uint32_t s   = s_uptime_sec;
    uint32_t hh  = (s / 3600) % 24;
    uint32_t mm  = (s / 60) % 60;
    uint32_t ss  = s % 60;
    snprintf(out, 24, "2026-09-30T%02lu:%02lu:%02lu",
             (unsigned long)hh,
             (unsigned long)mm,
             (unsigned long)ss);
}

// =============================================================================
// MQTT CONNECT packet
// =============================================================================
static void mqtt_send_connect(const MqttConfig_t *cfg)
{
    uint8_t  payload[256];
    uint16_t pi = 0;

    // Variable header: Protocol Name + Level + Connect Flags + Keepalive
    const char *proto = "MQTT";
    payload[pi++] = 0x00; payload[pi++] = 0x04;
    memcpy(&payload[pi], proto, 4); pi += 4;
    payload[pi++] = 0x04;  // Protocol Level 3.1.1

    // Connect flags: Clean Session=1, Will=1 (LWT), Will Retain=1, Will QoS=0
    // Will topic = s_t_lwt, Will message = "Offline"
    payload[pi++] = 0b00100110;  // clean=1, will=1, will_retain=1

    // Keepalive
    payload[pi++] = (uint8_t)(MQTT_KEEPALIVE_SEC >> 8);
    payload[pi++] = (uint8_t)(MQTT_KEEPALIVE_SEC);

    // Payload: Client ID
    pi += write_str(&payload[pi], cfg->client_id);

    // Will topic & message (LWT)
    pi += write_str(&payload[pi], s_t_lwt);
    pi += write_str(&payload[pi], "Offline");

    // Username & Password
    if (cfg->user[0]) {
        payload[pi - 6 - 1] |= 0x80;  // set username flag
        // Perbarui connect flags — lebih simpel: rebuild
    }

    // --- Rebuild dengan benar ---
    pi = 0;
    payload[pi++] = 0x00; payload[pi++] = 0x04;
    memcpy(&payload[pi], proto, 4); pi += 4;
    payload[pi++] = 0x04;

    uint8_t conn_flags = 0x02;  // clean session
    conn_flags |= 0x04;         // will flag
    conn_flags |= 0x20;         // will retain
    if (cfg->user[0])     conn_flags |= 0x80;
    if (cfg->password[0]) conn_flags |= 0x40;
    payload[pi++] = conn_flags;

    payload[pi++] = (uint8_t)(MQTT_KEEPALIVE_SEC >> 8);
    payload[pi++] = (uint8_t)(MQTT_KEEPALIVE_SEC);

    pi += write_str(&payload[pi], cfg->client_id);
    pi += write_str(&payload[pi], s_t_lwt);
    pi += write_str(&payload[pi], "Offline");
    if (cfg->user[0])     pi += write_str(&payload[pi], cfg->user);
    if (cfg->password[0]) pi += write_str(&payload[pi], cfg->password);

    // Fixed header
    uint8_t rem[4];
    uint8_t rem_len = encode_remaining(rem, pi);

    s_buf[0] = MQTT_CONNECT;
    memcpy(&s_buf[1], rem, rem_len);
    memcpy(&s_buf[1 + rem_len], payload, pi);
    s2_send(s_buf, 1 + rem_len + pi);
}

// =============================================================================
// MQTT PUBLISH (QoS 0)
// =============================================================================
void MQTT_Publish(const char *topic, const uint8_t *payload, uint16_t plen)
{
    uint16_t topic_len = (uint16_t)strlen(topic);
    uint32_t rem = 2 + topic_len + plen;  // 2 = topic length field

    uint8_t rem_enc[4];
    uint8_t rem_len = encode_remaining(rem_enc, rem);

    uint16_t i = 0;
    s_buf[i++] = MQTT_PUBLISH;  // QoS 0, no retain
    memcpy(&s_buf[i], rem_enc, rem_len); i += rem_len;
    s_buf[i++] = (uint8_t)(topic_len >> 8);
    s_buf[i++] = (uint8_t)(topic_len);
    memcpy(&s_buf[i], topic, topic_len); i += topic_len;
    memcpy(&s_buf[i], payload, plen);    i += plen;

    s2_send(s_buf, i);
    g_mqtt_pub_count++;
}

// =============================================================================
// MQTT SUBSCRIBE (QoS 0)
// =============================================================================
static void mqtt_subscribe(const char *topic)
{
    uint16_t topic_len = (uint16_t)strlen(topic);
    uint32_t rem = 2 + 2 + topic_len + 1;  // pkt_id + topic_len + topic + QoS

    uint8_t rem_enc[4];
    uint8_t rem_len = encode_remaining(rem_enc, rem);

    uint16_t i = 0;
    s_buf[i++] = MQTT_SUBSCRIBE;
    memcpy(&s_buf[i], rem_enc, rem_len); i += rem_len;
    s_buf[i++] = (uint8_t)(s_pkt_id >> 8);
    s_buf[i++] = (uint8_t)(s_pkt_id++);
    s_buf[i++] = (uint8_t)(topic_len >> 8);
    s_buf[i++] = (uint8_t)(topic_len);
    memcpy(&s_buf[i], topic, topic_len); i += topic_len;
    s_buf[i++] = 0x00;  // QoS 0

    s2_send(s_buf, i);
}

// =============================================================================
// MQTT PINGREQ
// =============================================================================
static void mqtt_pingreq(void)
{
    s_buf[0] = MQTT_PINGREQ;
    s_buf[1] = 0x00;
    s2_send(s_buf, 2);
}

// =============================================================================
// PUBLISH tele/STATE — mirip Tasmota Sonoff single relay
// =============================================================================
static void publish_state(const MqttConfig_t *cfg)
{
    char uptime_str[16];
    char time_str[24];
    format_uptime(uptime_str, s_uptime_sec);
    format_time(time_str);

    char ip_str[16];
    snprintf(ip_str, sizeof(ip_str), "%d.%d.%d.%d",
             g_dhcp_ip[0], g_dhcp_ip[1], g_dhcp_ip[2], g_dhcp_ip[3]);

    char json[400];
    snprintf(json, sizeof(json),
        "{"
        "\"Time\":\"%s\","
        "\"Uptime\":\"%s\","
        "\"UptimeSec\":%lu,"
        "\"Heap\":0,"
        "\"SleepMode\":\"None\","
        "\"Sleep\":0,"
        "\"LoadAvg\":100,"
        "\"MqttCount\":%d,"
        "\"POWER\":\"%s\","
        "\"Eth\":{"
            "\"IP\":\"%s\","
            "\"MAC\":\"00:08:DC:11:22:33\","
            "\"LinkCount\":1"
        "},"
        "\"Hostname\":\"%s\","
        "\"IPAddress\":\"%s\""
        "}",
        time_str,
        uptime_str,
        (unsigned long)s_uptime_sec,
        g_mqtt_conn_count,
        s_power_state ? "ON" : "OFF",
        ip_str,
        cfg->client_id,
        ip_str);

    MQTT_Publish(s_t_state, (uint8_t *)json, (uint16_t)strlen(json));
}

// =============================================================================
// PUBLISH tele/SENSOR — data sensor (dummy, forward variabel g_mqtt_sensor)
// =============================================================================
static void publish_sensor(void)
{
    char time_str[24];
    format_time(time_str);

    char json[200];
    snprintf(json, sizeof(json),
        "{"
        "\"Time\":\"%s\","
        "\"Switch1\":\"%s\","
        "\"ENERGY\":{"
            "\"TotalStartTime\":\"2026-09-30T00:00:00\","
            "\"Total\":0.000,"
            "\"Yesterday\":0.000,"
            "\"Today\":0.000,"
            "\"Period\":0,"
            "\"Power\":0,"
            "\"ApparentPower\":0,"
            "\"ReactivePower\":0,"
            "\"Factor\":0.00,"
            "\"Frequency\":50,"
            "\"Voltage\":%.0f,"
            "\"Current\":0.000"
        "}"
        "}",
        time_str,
        s_power_state ? "ON" : "OFF",
        g_mqtt_sensor.voltage * 100.0f);  // dummy voltage sebagai tegangan

    MQTT_Publish(s_t_sensor, (uint8_t *)json, (uint16_t)strlen(json));
}

// =============================================================================
// PUBLISH tele/INFO1, INFO2, INFO3 — dikirim sekali saat connect
// =============================================================================
static void publish_info(const MqttConfig_t *cfg)
{
    char t_info1[96], t_info2[96], t_info3[96];
    char base[80];

    // Buat base topic tanpa prefix
    MqttConfig_BuildTopic(cfg, "tele", base, sizeof(base));

    snprintf(t_info1, sizeof(t_info1), "%sINFO1", base);
    snprintf(t_info2, sizeof(t_info2), "%sINFO2", base);
    snprintf(t_info3, sizeof(t_info3), "%sINFO3", base);

    char ip_str[16];
    snprintf(ip_str, sizeof(ip_str), "%d.%d.%d.%d",
             g_dhcp_ip[0], g_dhcp_ip[1], g_dhcp_ip[2], g_dhcp_ip[3]);

    char json1[200];
    snprintf(json1, sizeof(json1),
        "{\"Info1\":{\"Module\":\"STM32F103+W5500\",\"Version\":\"1.0.0\","
        "\"FallbackTopic\":\"cmnd/%s_fb/\",\"GroupTopic\":\"cmnd/stm32s/\"}}",
        cfg->topic);
    MQTT_Publish(t_info1, (uint8_t *)json1, (uint16_t)strlen(json1));

    char json2[200];
    snprintf(json2, sizeof(json2),
        "{\"Info2\":{\"WebServerMode\":\"Admin\",\"Hostname\":\"%s\","
        "\"IPAddress\":\"%s\"}}",
        cfg->client_id, ip_str);
    MQTT_Publish(t_info2, (uint8_t *)json2, (uint16_t)strlen(json2));

    char json3[128];
    snprintf(json3, sizeof(json3),
        "{\"Info3\":{\"RestartReason\":\"Power on\",\"BootCount\":1}}");
    MQTT_Publish(t_info3, (uint8_t *)json3, (uint16_t)strlen(json3));
}

// =============================================================================
// HANDLE incoming MQTT packet (subscribe callback)
// =============================================================================
static void mqtt_handle_incoming(const MqttConfig_t *cfg)
{
    uint16_t rx_len = ((uint16_t)W5500_ReadReg(Sn_RX_RSR,     S2_REG_OP) << 8) |
                                  W5500_ReadReg(Sn_RX_RSR + 1, S2_REG_OP);
    if (rx_len == 0) return;

    uint16_t rx_rd = ((uint16_t)W5500_ReadReg(Sn_RX_RD,     S2_REG_OP) << 8) |
                                 W5500_ReadReg(Sn_RX_RD + 1, S2_REG_OP);

    uint16_t grab = (rx_len > MQTT_BUF_SIZE) ? MQTT_BUF_SIZE : rx_len;
    W5500_ReadBuf(rx_rd, S2_RX_OP, s_buf, grab);
    rx_rd += grab;
    W5500_WriteReg(Sn_RX_RD,     S2_REG_OP, (uint8_t)(rx_rd >> 8));
    W5500_WriteReg(Sn_RX_RD + 1, S2_REG_OP, (uint8_t)(rx_rd));
    W5500_WriteReg(Sn_CR,        S2_REG_OP, CMD_RECV);
    s2_wait_cr(10);

    uint8_t pkt_type = s_buf[0] & 0xF0;

    // CONNACK
    if (pkt_type == MQTT_CONNACK) {
        if (s_buf[3] == 0x00) {
            // Connect berhasil
            g_mqtt_conn_count++;
            g_mqtt_state = MQTT_STATE_CONNECTED;

            // Subscribe cmnd/topic/#
            char cmnd_wildcard[100];
            snprintf(cmnd_wildcard, sizeof(cmnd_wildcard), "%s#", s_t_cmnd);
            mqtt_subscribe(cmnd_wildcard);

            // Publish LWT Online
            MQTT_Publish(s_t_lwt, (uint8_t *)"Online", 6);

            // Publish INFO1/2/3
            publish_info(cfg);

            // Publish STATE + SENSOR pertama kali
            publish_state(cfg);
            publish_sensor();

            s_last_pub  = g_ms_tick;
            s_last_ping = g_ms_tick;
        } else {
            // Connect ditolak broker
            g_mqtt_state = MQTT_STATE_RECONNECT;
            s_tick_ref   = g_ms_tick;
        }
        return;
    }

    // PINGRESP
    if (pkt_type == MQTT_PINGRESP) return;

    // SUBACK
    if (pkt_type == MQTT_SUBACK) return;

    // PUBLISH dari broker (command)
    if (pkt_type == MQTT_PUBLISH) {
        // Parse topic length
        uint16_t topic_len = ((uint16_t)s_buf[2] << 8) | s_buf[3];
        if (topic_len + 4 > grab) return;

        char topic_in[96];
        if (topic_len >= sizeof(topic_in)) return;
        memcpy(topic_in, &s_buf[4], topic_len);
        topic_in[topic_len] = '\0';

        // Payload (QoS 0 — tidak ada packet ID)
        uint8_t  *pay     = &s_buf[4 + topic_len];
        uint16_t  pay_len = grab - 4 - topic_len;
        char payload_str[64] = {0};
        uint16_t copy = (pay_len < 63) ? pay_len : 63;
        memcpy(payload_str, pay, copy);
        payload_str[copy] = '\0';

        // Cek apakah command POWER
        char t_power_cmd[100];
        snprintf(t_power_cmd, sizeof(t_power_cmd), "%sPOWER", s_t_cmnd);

        if (strcmp(topic_in, t_power_cmd) == 0) {
            if (strcasecmp(payload_str, "ON") == 0)     s_power_state = 1;
            else if (strcasecmp(payload_str, "OFF") == 0) s_power_state = 0;
            else if (strcasecmp(payload_str, "TOGGLE") == 0) s_power_state ^= 1;

            // Balas via stat/RESULT dan stat/POWER
            char result_json[32];
            snprintf(result_json, sizeof(result_json),
                "{\"POWER\":\"%s\"}", s_power_state ? "ON" : "OFF");
            MQTT_Publish(s_t_result, (uint8_t *)result_json,
                         (uint16_t)strlen(result_json));
            MQTT_Publish(s_t_power,
                         (uint8_t *)(s_power_state ? "ON" : "OFF"),
                         s_power_state ? 2 : 3);
        }

        // Cek command TelePeriod
        char t_tele_cmd[100];
        snprintf(t_tele_cmd, sizeof(t_tele_cmd), "%sTelePeriod", s_t_cmnd);
        if (strcasecmp(topic_in, t_tele_cmd) == 0) {
            uint16_t period = (uint16_t)atoi(payload_str);
            if (period >= 10 && period <= 3600) {
                s_pub_interval = (uint32_t)period * 1000UL;
            }
        }
    }
}

// =============================================================================
// FUNGSI PUBLIK: Init
// =============================================================================
void MQTT_Init(void)
{
    // Alokasi buffer Socket 2
    W5500_WriteReg(0x001E, S2_REG_OP, 2);  // Socket 2 TX 2KB
    W5500_WriteReg(0x001F, S2_REG_OP, 2);  // Socket 2 RX 2KB

    g_mqtt_state    = MQTT_STATE_IDLE;
    s_uptime_sec    = 0;
    s_last_uptime   = g_ms_tick;
}

// =============================================================================
// FUNGSI PUBLIK: Process (dipanggil setiap loop)
// =============================================================================
void MQTT_Process(const MqttConfig_t *cfg)
{
    if (!cfg->enabled) {
        g_mqtt_state = MQTT_STATE_DISABLED;
        return;
    }

    // Update uptime
    if ((g_ms_tick - s_last_uptime) >= 1000) {
        s_uptime_sec++;
        s_last_uptime += 1000;
    }

    // Interval publish dari config
    if (s_pub_interval == 0) {
        s_pub_interval = (uint32_t)cfg->tele_period * 1000UL;
    }

    uint8_t sr = W5500_ReadReg(Sn_SR, S2_REG_OP);

    switch (g_mqtt_state) {

        // =====================================================================
        case MQTT_STATE_IDLE:
        // =====================================================================
        {
            // Bangun topic cache dari config
            char tele_base[80], stat_base[80], cmnd_base[80];
            MqttConfig_BuildTopic(cfg, "tele", tele_base, sizeof(tele_base));
            MqttConfig_BuildTopic(cfg, "stat", stat_base, sizeof(stat_base));
            MqttConfig_BuildTopic(cfg, "cmnd", cmnd_base, sizeof(cmnd_base));

            snprintf(s_t_lwt,    sizeof(s_t_lwt),    "%sLWT",    tele_base);
            snprintf(s_t_state,  sizeof(s_t_state),  "%sSTATE",  tele_base);
            snprintf(s_t_sensor, sizeof(s_t_sensor), "%sSENSOR", tele_base);
            snprintf(s_t_result, sizeof(s_t_result), "%sRESULT", stat_base);
            snprintf(s_t_power,  sizeof(s_t_power),  "%sPOWER",  stat_base);
            snprintf(s_t_cmnd,   sizeof(s_t_cmnd),   "%s",       cmnd_base);

            // Tutup socket dulu kalau perlu
            if (sr != SOCK_CLOSED) {
                W5500_WriteReg(Sn_CR, S2_REG_OP, CMD_CLOSE);
                s2_wait_cr(50);
                break;
            }

            // Buka socket TCP
            W5500_WriteReg(Sn_MR,      S2_REG_OP, 0x01);   // TCP mode
            W5500_WriteReg(Sn_PORT,    S2_REG_OP, 0x00);
            W5500_WriteReg(Sn_PORT+1,  S2_REG_OP, 0xC8);   // source port 200
            W5500_WriteReg(Sn_CR,      S2_REG_OP, CMD_OPEN);
            s2_wait_cr(50);

            // Set destination IP dan port broker
            W5500_WriteBuf(Sn_DIPR,    S2_REG_OP, (uint8_t *)cfg->host, 0);
            // Parse IP string ke bytes
            uint8_t ip[4] = {0};
            sscanf(cfg->host, "%hhu.%hhu.%hhu.%hhu",
                   &ip[0], &ip[1], &ip[2], &ip[3]);
            W5500_WriteBuf(Sn_DIPR,    S2_REG_OP, ip, 4);
            W5500_WriteReg(Sn_DPORT,   S2_REG_OP, (uint8_t)(cfg->port >> 8));
            W5500_WriteReg(Sn_DPORT+1, S2_REG_OP, (uint8_t)(cfg->port));

            // Connect
            W5500_WriteReg(Sn_CR, S2_REG_OP, CMD_CONNECT);
            s2_wait_cr(50);

            g_mqtt_state = MQTT_STATE_TCP_CONN;
            s_tick_ref   = g_ms_tick;
            break;
        }

        // =====================================================================
        case MQTT_STATE_TCP_CONN:
        // =====================================================================
            if (sr == SOCK_ESTABLISHED) {
                // TCP tersambung → kirim MQTT CONNECT
                mqtt_send_connect(cfg);
                g_mqtt_state = MQTT_STATE_MQTT_CONN;
                s_tick_ref   = g_ms_tick;
            } else if ((g_ms_tick - s_tick_ref) > MQTT_CONN_TIMEOUT_MS) {
                // Timeout → coba lagi
                W5500_WriteReg(Sn_CR, S2_REG_OP, CMD_CLOSE);
                s2_wait_cr(50);
                g_mqtt_state = MQTT_STATE_RECONNECT;
                s_tick_ref   = g_ms_tick;
            }
            break;

        // =====================================================================
        case MQTT_STATE_MQTT_CONN:
        // =====================================================================
            mqtt_handle_incoming(cfg);  // tunggu CONNACK
            if (g_mqtt_state == MQTT_STATE_CONNECTED) break;  // berhasil
            if ((g_ms_tick - s_tick_ref) > MQTT_CONN_TIMEOUT_MS) {
                W5500_WriteReg(Sn_CR, S2_REG_OP, CMD_CLOSE);
                s2_wait_cr(50);
                g_mqtt_state = MQTT_STATE_RECONNECT;
                s_tick_ref   = g_ms_tick;
            }
            break;

        // =====================================================================
        case MQTT_STATE_CONNECTED:
        // =====================================================================
            // Cek koneksi TCP masih hidup
            if (sr != SOCK_ESTABLISHED) {
                g_mqtt_state = MQTT_STATE_RECONNECT;
                s_tick_ref   = g_ms_tick;
                break;
            }

            // Baca incoming (command dari broker)
            mqtt_handle_incoming(cfg);

            // PINGREQ setiap KEEPALIVE/2 detik
            if ((g_ms_tick - s_last_ping) >= (MQTT_KEEPALIVE_SEC * 500UL)) {
                mqtt_pingreq();
                s_last_ping = g_ms_tick;
            }

            // Publish tele STATE + SENSOR setiap tele_period
            if ((g_ms_tick - s_last_pub) >= s_pub_interval) {
                publish_state(cfg);
                publish_sensor();
                s_last_pub = g_ms_tick;
            }
            break;

        // =====================================================================
        case MQTT_STATE_RECONNECT:
        // =====================================================================
            // Tunggu 5 detik sebelum reconnect
            if ((g_ms_tick - s_tick_ref) > 5000) {
                g_mqtt_state = MQTT_STATE_IDLE;
            }
            break;

        case MQTT_STATE_DISABLED:
        default:
            break;
    }
}

// =============================================================================
// FUNGSI PUBLIK: IsConnected
// =============================================================================
uint8_t MQTT_IsConnected(void)
{
    return (g_mqtt_state == MQTT_STATE_CONNECTED) ? 1 : 0;
}
