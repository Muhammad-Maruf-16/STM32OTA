// =============================================================================
// PATCH main.c — Tambahan untuk MQTT Config
// =============================================================================
//
// 1. Di bagian #include (USER CODE BEGIN Includes):
//
//    #include "mqtt_config.h"
//    #include "web_config.h"
//
// 2. Di USER CODE BEGIN 2, setelah W5500_InitNetwork() dan DHCP_Init():
//
//    WebConfig_Init();
//
// 3. Di Process_Web_OTA(), TAMBAHKAN routing /config SEBELUM routing "GET /":
//
//    // ============================================================
//    // /config — Halaman konfigurasi MQTT
//    // ============================================================
//    if (strstr((char *)ram_buffer, "/config") != NULL) {
//        WebConfig_Handle(ram_buffer, fetch);
//
//        rx_rd += rx_len;
//        W5500_WriteReg(Sn_RX_RD,     W5500_S0_REG_OP, (uint8_t)(rx_rd >> 8));
//        W5500_WriteReg(Sn_RX_RD + 1, W5500_S0_REG_OP, (uint8_t)rx_rd);
//        W5500_WriteReg(Sn_CR, W5500_S0_REG_OP, CMD_RECV);
//        while (W5500_ReadReg(Sn_CR, W5500_S0_REG_OP));
//        W5500_WriteReg(Sn_CR, W5500_S0_REG_OP, CMD_DISCON);
//        while (W5500_ReadReg(Sn_CR, W5500_S0_REG_OP));
//        return;
//    }
//
//    // ============================================================
//    // GET / — Kirim halaman web OTA (sudah ada sebelumnya)
//    // ============================================================
//    if (strstr((char *)ram_buffer, "GET /") != NULL) {
//        ... (kode yang sudah ada)
//    }
//
// =============================================================================
// CATATAN:
// - Tidak perlu tambah #define apapun di main.c
// - FLASH_MQTT_META = 0x00030000 sudah didefinisikan di mqtt_config.h
// - Akses /config via browser: http://<IP>/config
// - Akses JSON data via: http://<IP>/config/data
// =============================================================================
