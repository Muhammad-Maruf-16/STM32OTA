#include "mqtt_config.h"
#include "main.h"
#include <string.h>

// =============================================================================
// FORWARD DECLARATION — fungsi SPI Flash dari main.c
// =============================================================================
extern void     ExtFlash_EraseSector(uint32_t addr);
extern void     ExtFlash_WritePage  (uint32_t addr, const uint8_t *data, uint16_t len);
extern void     Flash_ReadBytes     (uint32_t addr, uint8_t *buf, uint32_t len);

// =============================================================================
// FUNGSI PUBLIK
// =============================================================================

void MqttConfig_SetDefault(MqttConfig_t *cfg)
{
    memset(cfg, 0, sizeof(MqttConfig_t));

    strncpy(cfg->host,      MQTT_DEFAULT_HOST,      sizeof(cfg->host)      - 1);
    strncpy(cfg->user,      MQTT_DEFAULT_USER,      sizeof(cfg->user)      - 1);
    strncpy(cfg->password,  MQTT_DEFAULT_PASSWORD,  sizeof(cfg->password)  - 1);
    strncpy(cfg->topic,     MQTT_DEFAULT_TOPIC,     sizeof(cfg->topic)     - 1);
    strncpy(cfg->client_id, MQTT_DEFAULT_CLIENT_ID, sizeof(cfg->client_id) - 1);

    cfg->port    = MQTT_DEFAULT_PORT;
    cfg->enabled = MQTT_DEFAULT_ENABLED;
    cfg->magic   = MQTT_CONFIG_MAGIC;
}

int MqttConfig_Load(MqttConfig_t *cfg)
{
    MqttConfig_t tmp;
    memset(&tmp, 0, sizeof(MqttConfig_t));

    Flash_ReadBytes(FLASH_MQTT_META, (uint8_t *)&tmp, sizeof(MqttConfig_t));

    if (tmp.magic == MQTT_CONFIG_MAGIC) {
        memcpy(cfg, &tmp, sizeof(MqttConfig_t));
        return 0;   // sukses load dari flash
    }

    // Belum pernah disimpan atau corrupt → pakai default
    MqttConfig_SetDefault(cfg);
    return 1;
}

int MqttConfig_Save(const MqttConfig_t *cfg)
{
    // Erase sector dulu
    ExtFlash_EraseSector(FLASH_MQTT_META);

    // Tulis per page 256 byte
    const uint8_t *ptr       = (const uint8_t *)cfg;
    uint32_t       remaining = sizeof(MqttConfig_t);
    uint32_t       addr      = FLASH_MQTT_META;

    while (remaining > 0) {
        uint16_t chunk = (remaining > 256) ? 256 : (uint16_t)remaining;

        // Pastikan tidak melewati page boundary 256 byte
        uint16_t page_offset = (uint16_t)(addr & 0xFF);
        uint16_t space       = 256 - page_offset;
        if (chunk > space) chunk = space;

        ExtFlash_WritePage(addr, ptr, chunk);

        ptr       += chunk;
        addr      += chunk;
        remaining -= chunk;
    }

    // Verifikasi — baca balik dan cek magic
    uint32_t magic_check = 0;
    Flash_ReadBytes(FLASH_MQTT_META + offsetof(MqttConfig_t, magic),
                    (uint8_t *)&magic_check, 4);

    return (magic_check == MQTT_CONFIG_MAGIC) ? 0 : -1;
}
