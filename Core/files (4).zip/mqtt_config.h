#ifndef MQTT_CONFIG_H
#define MQTT_CONFIG_H

#include <stdint.h>

// =============================================================================
// ALAMAT SPI FLASH UNTUK CONFIG MQTT
// =============================================================================
#define FLASH_MQTT_META     0x00030000U   // 4KB sector untuk magic + config
#define FLASH_MQTT_DATA     0x00031000U   // 4KB sector backup (opsional)

// =============================================================================
// STRUCT CONFIG MQTT (mirip Tasmota)
// Total size: 64+2+32+32+32+32+1+1+4 = 200 byte → muat dalam 1 sektor 4KB
// =============================================================================
typedef struct {
    char     host     [64];   // MQTT Broker IP / hostname
    uint16_t port;            // Default: 1883
    char     user     [32];   // MQTT Username
    char     password [32];   // MQTT Password
    char     topic    [32];   // Base topic (misal: "stm32/data")
    char     client_id[32];   // Client ID (misal: "STM32_W5500")
    uint8_t  enabled;         // 1 = aktif, 0 = nonaktif
    uint8_t  _pad[3];         // padding 4-byte aligned
    uint32_t magic;           // 0xABCD1234 = config valid
} MqttConfig_t;

#define MQTT_CONFIG_MAGIC   0xABCD1234U
#define MQTT_CONFIG_SIZE    sizeof(MqttConfig_t)

// =============================================================================
// DEFAULT CONFIG
// =============================================================================
#define MQTT_DEFAULT_HOST       "192.168.1.100"
#define MQTT_DEFAULT_PORT       1883
#define MQTT_DEFAULT_USER       ""
#define MQTT_DEFAULT_PASSWORD   ""
#define MQTT_DEFAULT_TOPIC      "stm32/data"
#define MQTT_DEFAULT_CLIENT_ID  "STM32_W5500"
#define MQTT_DEFAULT_ENABLED    1

// =============================================================================
// FUNGSI PUBLIK
// =============================================================================

/**
 * @brief  Load config MQTT dari SPI Flash.
 *         Jika magic tidak cocok → isi default.
 * @param  cfg  Pointer ke struct output
 * @retval 0 sukses load dari flash, 1 pakai default (belum pernah disimpan)
 */
int  MqttConfig_Load(MqttConfig_t *cfg);

/**
 * @brief  Simpan config MQTT ke SPI Flash.
 *         Akan erase sector dulu sebelum write.
 * @param  cfg  Pointer ke struct yang mau disimpan
 * @retval 0 sukses, -1 error
 */
int  MqttConfig_Save(const MqttConfig_t *cfg);

/**
 * @brief  Isi struct dengan nilai default.
 * @param  cfg  Pointer ke struct output
 */
void MqttConfig_SetDefault(MqttConfig_t *cfg);

#endif /* MQTT_CONFIG_H */
